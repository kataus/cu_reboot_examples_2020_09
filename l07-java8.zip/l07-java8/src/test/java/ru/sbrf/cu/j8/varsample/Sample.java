package ru.sbrf.cu.j8.varsample;

import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Sample {
    @Test
    public void testDate(){
        Date date = new Date();
        Calendar calendar = new GregorianCalendar();
        // TODO внимательно на месяц
        calendar.set( 2015, 9, 16 );
        date = calendar.getTime();
    }

    @Test
    public void printTodayInAnyCalendars(){

    }


}
